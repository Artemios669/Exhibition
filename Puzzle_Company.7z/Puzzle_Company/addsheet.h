#ifndef ADDSHEET_H
#define ADDSHEET_H

#include <QDialog>
#include <addpuzzles.h>
namespace Ui {
class AddSheet;
}

class AddSheet : public QDialog
{
    Q_OBJECT

public:
    explicit AddSheet(QWidget *parent = nullptr);
    ~AddSheet();
signals:
    void requestUpdate();
private slots:

    void on_pushButton_AddSheet_clicked();

    void on_comboBox_choiceWood_currentTextChanged(const QString &arg1);

    void on_comboBox_choiceThickness_currentTextChanged(const QString &arg1);

private:
    Ui::AddSheet *ui;
    AddPuzzles *addPuzzles;
    QString name;
};

#endif // ADDSHEET_H
