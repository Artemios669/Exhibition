/********************************************************************************
** Form generated from reading UI file 'addpuzzles.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPUZZLES_H
#define UI_ADDPUZZLES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AddPuzzles
{
public:
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_puzzleName;
    QLabel *label_3;
    QComboBox *comboBox_Sheets;
    QLabel *label_4;
    QLineEdit *lineEdit_Quantity;
    QLabel *label_5;
    QPushButton *pushButton_AddSheet;
    QLabel *label_6;
    QPushButton *pushButton_AddPuzzle;
    QLabel *label_price;

    void setupUi(QDialog *AddPuzzles)
    {
        if (AddPuzzles->objectName().isEmpty())
            AddPuzzles->setObjectName("AddPuzzles");
        AddPuzzles->resize(650, 492);
        label = new QLabel(AddPuzzles);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 0, 101, 31));
        label_2 = new QLabel(AddPuzzles);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 70, 121, 20));
        lineEdit_puzzleName = new QLineEdit(AddPuzzles);
        lineEdit_puzzleName->setObjectName("lineEdit_puzzleName");
        lineEdit_puzzleName->setGeometry(QRect(150, 70, 221, 28));
        label_3 = new QLabel(AddPuzzles);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(20, 130, 111, 20));
        comboBox_Sheets = new QComboBox(AddPuzzles);
        comboBox_Sheets->setObjectName("comboBox_Sheets");
        comboBox_Sheets->setGeometry(QRect(140, 130, 221, 28));
        label_4 = new QLabel(AddPuzzles);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(20, 180, 111, 51));
        lineEdit_Quantity = new QLineEdit(AddPuzzles);
        lineEdit_Quantity->setObjectName("lineEdit_Quantity");
        lineEdit_Quantity->setGeometry(QRect(150, 190, 113, 28));
        label_5 = new QLabel(AddPuzzles);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(220, 350, 63, 20));
        pushButton_AddSheet = new QPushButton(AddPuzzles);
        pushButton_AddSheet->setObjectName("pushButton_AddSheet");
        pushButton_AddSheet->setGeometry(QRect(370, 130, 201, 29));
        label_6 = new QLabel(AddPuzzles);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(20, 270, 141, 20));
        pushButton_AddPuzzle = new QPushButton(AddPuzzles);
        pushButton_AddPuzzle->setObjectName("pushButton_AddPuzzle");
        pushButton_AddPuzzle->setGeometry(QRect(12, 420, 131, 29));
        label_price = new QLabel(AddPuzzles);
        label_price->setObjectName("label_price");
        label_price->setGeometry(QRect(190, 270, 63, 20));

        retranslateUi(AddPuzzles);

        QMetaObject::connectSlotsByName(AddPuzzles);
    } // setupUi

    void retranslateUi(QDialog *AddPuzzles)
    {
        AddPuzzles->setWindowTitle(QCoreApplication::translate("AddPuzzles", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("AddPuzzles", "\320\264\320\276\320\261\320\260\320\262\321\214 \320\277\320\260\320\267\320\273", nullptr));
        label_2->setText(QCoreApplication::translate("AddPuzzles", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265 \320\277\320\260\320\267\320\273\320\260", nullptr));
        lineEdit_puzzleName->setText(QString());
        label_3->setText(QCoreApplication::translate("AddPuzzles", "\320\244\320\260\320\275\320\265\321\200\320\275\321\213\320\271 \320\273\320\270\321\201\321\202", nullptr));
        label_4->setText(QCoreApplication::translate("AddPuzzles", "<html><head/><body><p>\320\232\320\276\320\273\320\270\321\207\320\265\321\201\321\202\320\262\320\276</p><p>\320\264\320\265\321\202\320\260\320\273\320\265\320\271, \321\210\321\202</p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("AddPuzzles", "\320\234\320\260\320\272\320\265\321\202", nullptr));
        pushButton_AddSheet->setText(QCoreApplication::translate("AddPuzzles", "\320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\204\320\260\320\275\320\265\321\200\320\275\321\213\320\271 \320\273\320\270\321\201\321\202", nullptr));
        label_6->setText(QCoreApplication::translate("AddPuzzles", "\320\224\320\265\320\271\321\201\321\202\320\262\321\203\321\216\321\211\320\260\321\217 \321\206\320\265\320\275\320\260:", nullptr));
        pushButton_AddPuzzle->setText(QCoreApplication::translate("AddPuzzles", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\277\320\260\320\267\320\273", nullptr));
        label_price->setText(QCoreApplication::translate("AddPuzzles", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddPuzzles: public Ui_AddPuzzles {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPUZZLES_H
