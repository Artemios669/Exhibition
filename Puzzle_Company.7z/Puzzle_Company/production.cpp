#include "production.h"
#include "ui_production.h"
#include <QSqlQueryModel>
#include <QStandardItemModel>
#include <qDebug>
Production::Production(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Production)
{
    ui->setupUi(this);

    QSqlQueryModel *model = new QSqlQueryModel();
    QSqlQuery query = DatabaseManager::instance().createQuery();
    query.exec("SELECT * FROM production");
    model->setQuery(query);
    ui->tableView->setModel(model);

    for (int i = 0; i < ui->tableView->model()->rowCount(); i++)
    {
        comboBox = new QComboBox();
        comboBox->addItem("Принято на производство");
        comboBox->addItem("Выполнено");
        ui->tableView->setIndexWidget(ui->tableView->model()->index(i, 4), comboBox);
        comboBox->setCurrentIndex(0);

        connect(comboBox, &QComboBox::currentTextChanged, this, &Production::UpdateStatus);
    }
}

Production::~Production()
{
    delete ui;
}

void Production::on_pushButton_addProduction_clicked()
{
    addProduction = new AddProduction(this);
    addProduction->show();
}

void Production::UpdateStatus(const QString &arg1)
{
    QSqlQuery query = DatabaseManager::instance().createQuery();

    QModelIndex index = ui->tableView->model()->index(0, 1);
    QVariant cellData = ui->tableView->model()->data(index);
    QString order_name = cellData.toString();

    query.prepare("UPDATE production SET status = :arg1 WHERE order_name_id = :order_name;");
    query.bindValue(":arg1", arg1);
    query.bindValue(":order_name", order_name);
    query.exec();
    qDebug() << order_name << arg1;

    if (arg1 == "Принято в производство")
    {
        comboBox->setCurrentIndex(0);
        query.prepare("UPDATE order_list SET status = 'На производстве' WHERE order_name = :order_name");
        query.bindValue(":order_name", order_name);
        query.exec();
    }
    else if (arg1 == "Выполнено")
    {
        query.prepare("UPDATE order_list SET status = 'Готов к отгрузке' WHERE order_name = :order_name");
        query.bindValue(":order_name", order_name);
        query.exec();
    }
}
