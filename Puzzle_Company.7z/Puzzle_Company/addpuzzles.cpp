#include "addpuzzles.h"
#include "ui_addpuzzles.h"
#include "databasemanager.h"
#include <QSqlQueryModel>
#include <QDebug>
#include "addsheet.h"
AddPuzzles::AddPuzzles(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddPuzzles)
{
    ui->setupUi(this);

    modal = new QSqlQueryModel();

    UpdateInfo();

}

AddPuzzles::~AddPuzzles()
{
    delete ui;
}

void AddPuzzles::UpdateInformation()
{
    qDebug() << "called UpdateInfo";
    UpdateInfo();
}

void AddPuzzles::on_pushButton_AddSheet_clicked()
{
    AddSheet *addSheet;
    addSheet = new AddSheet(this);
    addSheet->show();
}

void AddPuzzles::UpdateInfo()
{
    QSqlQuery query = DatabaseManager::instance().createQuery();
    query.exec("SELECT name FROM sheets;");


    modal->setQuery(query);
    ui->comboBox_Sheets->setModel(modal);
    //qDebug() << "Данные обновились";
}

void AddPuzzles::on_pushButton_AddPuzzle_clicked()
{
    QSqlQuery query = DatabaseManager::instance().createQuery();

    QString name = ui->lineEdit_puzzleName->text();
    QString type_sheet = ui->comboBox_Sheets->currentText();
    int quantity = ui->lineEdit_Quantity->text().toInt();
    QString image_path = "C/test/testing";
    int price = ui->label_price->text().toInt();

    query.prepare("INSERT INTO puzzles (name, type_sheet, quantity, image_path, price) VALUES (:name, :type_sheet, :quantity, :image_path, :price)");
    query.bindValue(":name", name);
    query.bindValue(":type_sheet",type_sheet);
    query.bindValue(":quantity", quantity);
    query.bindValue(":image_path", image_path);
    query.bindValue(":price", price);
    //qDebug() << name << type_sheet << quantity << image_path << price;
    query.exec();
    close();
}


void AddPuzzles::on_comboBox_Sheets_currentTextChanged(const QString &arg1)
{
    QSqlQuery query_price_now = DatabaseManager::instance().createQuery();
    query_price_now.prepare("SELECT * FROM sheets WHERE name = :arg1");
    query_price_now.bindValue(":arg1", arg1);
    query_price_now.exec();
    query_price_now.next();
    QString price = query_price_now.value("price").toString();
    ui->label_price->setText(price);
}

