/********************************************************************************
** Form generated from reading UI file 'addproduction.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPRODUCTION_H
#define UI_ADDPRODUCTION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_AddProduction
{
public:
    QLabel *label_3;
    QComboBox *comboBox_StatusProduce;
    QLineEdit *lineEdit_CompletedDate;
    QLineEdit *lineEdit_RegistrationDate;
    QLabel *label;
    QLabel *label_4;
    QComboBox *comboBox_OrderName;
    QLabel *label_2;
    QTableView *tableView;
    QPushButton *pushButton_addProduction;

    void setupUi(QDialog *AddProduction)
    {
        if (AddProduction->objectName().isEmpty())
            AddProduction->setObjectName("AddProduction");
        AddProduction->resize(605, 423);
        label_3 = new QLabel(AddProduction);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(30, 150, 131, 71));
        comboBox_StatusProduce = new QComboBox(AddProduction);
        comboBox_StatusProduce->addItem(QString());
        comboBox_StatusProduce->addItem(QString());
        comboBox_StatusProduce->setObjectName("comboBox_StatusProduce");
        comboBox_StatusProduce->setGeometry(QRect(380, 30, 211, 28));
        lineEdit_CompletedDate = new QLineEdit(AddProduction);
        lineEdit_CompletedDate->setObjectName("lineEdit_CompletedDate");
        lineEdit_CompletedDate->setGeometry(QRect(180, 170, 171, 28));
        lineEdit_RegistrationDate = new QLineEdit(AddProduction);
        lineEdit_RegistrationDate->setObjectName("lineEdit_RegistrationDate");
        lineEdit_RegistrationDate->setGeometry(QRect(180, 110, 171, 28));
        label = new QLabel(AddProduction);
        label->setObjectName("label");
        label->setGeometry(QRect(30, 100, 131, 71));
        label_4 = new QLabel(AddProduction);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(320, 30, 63, 20));
        comboBox_OrderName = new QComboBox(AddProduction);
        comboBox_OrderName->setObjectName("comboBox_OrderName");
        comboBox_OrderName->setGeometry(QRect(180, 70, 161, 28));
        label_2 = new QLabel(AddProduction);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(30, 70, 121, 20));
        tableView = new QTableView(AddProduction);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(110, 210, 341, 161));
        pushButton_addProduction = new QPushButton(AddProduction);
        pushButton_addProduction->setObjectName("pushButton_addProduction");
        pushButton_addProduction->setGeometry(QRect(80, 390, 211, 29));

        retranslateUi(AddProduction);

        QMetaObject::connectSlotsByName(AddProduction);
    } // setupUi

    void retranslateUi(QDialog *AddProduction)
    {
        AddProduction->setWindowTitle(QCoreApplication::translate("AddProduction", "Dialog", nullptr));
        label_3->setText(QCoreApplication::translate("AddProduction", "<html><head/><body><p>\320\224\320\260\321\202\320\260 \320\262\321\213\320\277\320\276\320\273\320\275\320\265\320\275\320\270\321\217:</p></body></html>", nullptr));
        comboBox_StatusProduce->setItemText(0, QCoreApplication::translate("AddProduction", "\320\237\321\200\320\270\320\275\321\217\321\202\320\276 \320\262 \320\277\321\200\320\276\320\270\320\267\320\262\320\276\320\264\321\201\321\202\320\262\320\276", nullptr));
        comboBox_StatusProduce->setItemText(1, QCoreApplication::translate("AddProduction", "\320\222\321\213\320\277\320\276\320\273\320\275\320\265\320\275\320\276", nullptr));

        label->setText(QCoreApplication::translate("AddProduction", "<html><head/><body><p>\320\224\320\260\321\202\320\260 \321\200\320\265\320\263\320\270\321\201\321\202\321\200\320\260\321\206\320\270\320\270</p><p>\320\267\320\260\320\264\320\260\320\275\320\270\321\217:</p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("AddProduction", "\320\241\321\202\320\260\321\202\321\203\321\201:", nullptr));
        label_2->setText(QCoreApplication::translate("AddProduction", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265 \320\267\320\260\320\272\320\260\320\267\320\260", nullptr));
        pushButton_addProduction->setText(QCoreApplication::translate("AddProduction", "\320\236\321\202\320\277\321\200\320\260\320\262\320\270\321\202\321\214 \320\275\320\260 \320\277\321\200\320\276\320\270\320\267\320\262\320\276\320\264\321\201\321\202\320\262\320\276", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddProduction: public Ui_AddProduction {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPRODUCTION_H
