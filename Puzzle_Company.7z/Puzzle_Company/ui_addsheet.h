/********************************************************************************
** Form generated from reading UI file 'addsheet.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDSHEET_H
#define UI_ADDSHEET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AddSheet
{
public:
    QLabel *label;
    QLineEdit *lineEdit_name;
    QLabel *label_2;
    QComboBox *comboBox_choiceWood;
    QLabel *label_3;
    QPushButton *pushButton_AddSheet;
    QComboBox *comboBox_choiceThickness;

    void setupUi(QDialog *AddSheet)
    {
        if (AddSheet->objectName().isEmpty())
            AddSheet->setObjectName("AddSheet");
        AddSheet->resize(400, 300);
        label = new QLabel(AddSheet);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 40, 111, 20));
        lineEdit_name = new QLineEdit(AddSheet);
        lineEdit_name->setObjectName("lineEdit_name");
        lineEdit_name->setGeometry(QRect(150, 40, 113, 28));
        label_2 = new QLabel(AddSheet);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 90, 111, 20));
        comboBox_choiceWood = new QComboBox(AddSheet);
        comboBox_choiceWood->setObjectName("comboBox_choiceWood");
        comboBox_choiceWood->setGeometry(QRect(150, 90, 82, 28));
        label_3 = new QLabel(AddSheet);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(20, 150, 91, 20));
        pushButton_AddSheet = new QPushButton(AddSheet);
        pushButton_AddSheet->setObjectName("pushButton_AddSheet");
        pushButton_AddSheet->setGeometry(QRect(30, 260, 83, 29));
        comboBox_choiceThickness = new QComboBox(AddSheet);
        comboBox_choiceThickness->addItem(QString());
        comboBox_choiceThickness->addItem(QString());
        comboBox_choiceThickness->addItem(QString());
        comboBox_choiceThickness->addItem(QString());
        comboBox_choiceThickness->setObjectName("comboBox_choiceThickness");
        comboBox_choiceThickness->setGeometry(QRect(150, 150, 82, 28));

        retranslateUi(AddSheet);

        QMetaObject::connectSlotsByName(AddSheet);
    } // setupUi

    void retranslateUi(QDialog *AddSheet)
    {
        AddSheet->setWindowTitle(QCoreApplication::translate("AddSheet", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("AddSheet", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265 \320\273\320\270\321\201\321\202\320\260", nullptr));
        lineEdit_name->setText(QCoreApplication::translate("AddSheet", "\320\221\320\265\321\200\321\221\320\267\320\260, ? \320\274\320\274", nullptr));
        label_2->setText(QCoreApplication::translate("AddSheet", "\320\222\320\270\320\264 \320\264\321\200\320\265\320\262\320\265\321\201\320\270\320\275\321\213", nullptr));
        label_3->setText(QCoreApplication::translate("AddSheet", "\320\242\320\276\320\273\321\211\320\270\320\275\320\260, \320\274\320\274", nullptr));
        pushButton_AddSheet->setText(QCoreApplication::translate("AddSheet", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        comboBox_choiceThickness->setItemText(0, QCoreApplication::translate("AddSheet", "3", nullptr));
        comboBox_choiceThickness->setItemText(1, QCoreApplication::translate("AddSheet", "4", nullptr));
        comboBox_choiceThickness->setItemText(2, QCoreApplication::translate("AddSheet", "6", nullptr));
        comboBox_choiceThickness->setItemText(3, QCoreApplication::translate("AddSheet", "9", nullptr));

    } // retranslateUi

};

namespace Ui {
    class AddSheet: public Ui_AddSheet {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDSHEET_H
