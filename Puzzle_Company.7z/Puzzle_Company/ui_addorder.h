/********************************************************************************
** Form generated from reading UI file 'addorder.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDORDER_H
#define UI_ADDORDER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_AddOrder
{
public:
    QLabel *label;
    QLineEdit *lineEdit_RegistrationDate;
    QLabel *label_2;
    QComboBox *comboBox_Clients;
    QLabel *label_3;
    QTableWidget *tableWidget;
    QLabel *label_4;
    QComboBox *comboBox_Status;
    QPushButton *pushButton_AddOrder;
    QLineEdit *lineEdit_CompleteDate;
    QLabel *label_5;
    QLineEdit *lineEdit_name;

    void setupUi(QDialog *AddOrder)
    {
        if (AddOrder->objectName().isEmpty())
            AddOrder->setObjectName("AddOrder");
        AddOrder->resize(666, 384);
        label = new QLabel(AddOrder);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 70, 131, 71));
        lineEdit_RegistrationDate = new QLineEdit(AddOrder);
        lineEdit_RegistrationDate->setObjectName("lineEdit_RegistrationDate");
        lineEdit_RegistrationDate->setGeometry(QRect(160, 90, 171, 28));
        label_2 = new QLabel(AddOrder);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 160, 63, 20));
        comboBox_Clients = new QComboBox(AddOrder);
        comboBox_Clients->setObjectName("comboBox_Clients");
        comboBox_Clients->setGeometry(QRect(150, 160, 271, 28));
        label_3 = new QLabel(AddOrder);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(20, 170, 131, 71));
        tableWidget = new QTableWidget(AddOrder);
        if (tableWidget->columnCount() < 4)
            tableWidget->setColumnCount(4);
        if (tableWidget->rowCount() < 2)
            tableWidget->setRowCount(2);
        tableWidget->setObjectName("tableWidget");
        tableWidget->setGeometry(QRect(60, 230, 531, 101));
        tableWidget->setRowCount(2);
        tableWidget->setColumnCount(4);
        label_4 = new QLabel(AddOrder);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(420, 20, 63, 20));
        comboBox_Status = new QComboBox(AddOrder);
        comboBox_Status->setObjectName("comboBox_Status");
        comboBox_Status->setGeometry(QRect(471, 20, 131, 28));
        pushButton_AddOrder = new QPushButton(AddOrder);
        pushButton_AddOrder->setObjectName("pushButton_AddOrder");
        pushButton_AddOrder->setGeometry(QRect(40, 340, 141, 29));
        lineEdit_CompleteDate = new QLineEdit(AddOrder);
        lineEdit_CompleteDate->setObjectName("lineEdit_CompleteDate");
        lineEdit_CompleteDate->setGeometry(QRect(170, 190, 171, 28));
        label_5 = new QLabel(AddOrder);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(20, 30, 121, 20));
        lineEdit_name = new QLineEdit(AddOrder);
        lineEdit_name->setObjectName("lineEdit_name");
        lineEdit_name->setGeometry(QRect(160, 30, 113, 28));

        retranslateUi(AddOrder);

        QMetaObject::connectSlotsByName(AddOrder);
    } // setupUi

    void retranslateUi(QDialog *AddOrder)
    {
        AddOrder->setWindowTitle(QCoreApplication::translate("AddOrder", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("AddOrder", "<html><head/><body><p>\320\224\320\260\321\202\320\260 \321\200\320\265\320\263\320\270\321\201\321\202\321\200\320\260\321\206\320\270\320\270</p><p>\320\267\320\260\320\272\320\260\320\267\320\260:</p></body></html>", nullptr));
        lineEdit_RegistrationDate->setInputMask(QString());
        lineEdit_RegistrationDate->setText(QString());
        lineEdit_RegistrationDate->setPlaceholderText(QCoreApplication::translate("AddOrder", "\320\263\320\263\320\263\320\263-\320\274\320\274-\320\264\320\264 \321\207\321\207:\320\274\320\274", nullptr));
        label_2->setText(QCoreApplication::translate("AddOrder", "\320\232\320\273\320\270\320\265\320\275\321\202:", nullptr));
        label_3->setText(QCoreApplication::translate("AddOrder", "<html><head/><body><p>\320\224\320\260\321\202\320\260 \320\262\321\213\320\277\320\276\320\273\320\275\320\265\320\275\320\270\321\217:</p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("AddOrder", "\320\241\321\202\320\260\321\202\321\203\321\201:", nullptr));
        pushButton_AddOrder->setText(QCoreApplication::translate("AddOrder", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\267\320\260\320\272\320\260\320\267", nullptr));
        lineEdit_CompleteDate->setInputMask(QString());
        lineEdit_CompleteDate->setText(QString());
        lineEdit_CompleteDate->setPlaceholderText(QCoreApplication::translate("AddOrder", "\320\263\320\263\320\263\320\263-\320\274\320\274-\320\264\320\264 \321\207\321\207:\320\274\320\274", nullptr));
        label_5->setText(QCoreApplication::translate("AddOrder", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265 \320\267\320\260\320\272\320\260\320\267\320\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddOrder: public Ui_AddOrder {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDORDER_H
