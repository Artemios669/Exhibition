#ifndef ADDPRODUCTION_H
#define ADDPRODUCTION_H

#include <QDialog>
#include "databasemanager.h"
namespace Ui {
class AddProduction;
}

class AddProduction : public QDialog
{
    Q_OBJECT

public:
    explicit AddProduction(QWidget *parent = nullptr);
    ~AddProduction();

private slots:
    void on_comboBox_StatusProduce_currentTextChanged(const QString &arg1);

    void on_comboBox_OrderName_currentTextChanged(const QString &arg1);

    void on_pushButton_addProduction_clicked();

private:
    Ui::AddProduction *ui;
};

#endif // ADDPRODUCTION_H
