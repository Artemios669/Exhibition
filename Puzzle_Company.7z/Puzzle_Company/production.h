#ifndef PRODUCTION_H
#define PRODUCTION_H

#include <QDialog>
#include "databasemanager.h"
#include "addproduction.h"
#include <QComboBox>
namespace Ui {
class Production;
}

class Production : public QDialog
{
    Q_OBJECT

public:
    explicit Production(QWidget *parent = nullptr);
    ~Production();

private slots:
    void on_pushButton_addProduction_clicked();
    void UpdateStatus(const QString &arg1);

private:
    Ui::Production *ui;
    AddProduction *addProduction;
    QComboBox *comboBox;
};

#endif // PRODUCTION_H
