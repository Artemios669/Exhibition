/********************************************************************************
** Form generated from reading UI file 'production.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUCTION_H
#define UI_PRODUCTION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_Production
{
public:
    QPushButton *pushButton_addProduction;
    QTableView *tableView;

    void setupUi(QDialog *Production)
    {
        if (Production->objectName().isEmpty())
            Production->setObjectName("Production");
        Production->resize(844, 415);
        pushButton_addProduction = new QPushButton(Production);
        pushButton_addProduction->setObjectName("pushButton_addProduction");
        pushButton_addProduction->setGeometry(QRect(280, 370, 151, 29));
        tableView = new QTableView(Production);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(60, 20, 661, 301));

        retranslateUi(Production);

        QMetaObject::connectSlotsByName(Production);
    } // setupUi

    void retranslateUi(QDialog *Production)
    {
        Production->setWindowTitle(QCoreApplication::translate("Production", "Dialog", nullptr));
        pushButton_addProduction->setText(QCoreApplication::translate("Production", "\320\241\320\276\320\267\320\264\320\260\321\202\321\214 \320\267\320\260\320\264\320\260\320\275\320\270\320\265", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Production: public Ui_Production {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUCTION_H
