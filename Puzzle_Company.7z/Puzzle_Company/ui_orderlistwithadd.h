/********************************************************************************
** Form generated from reading UI file 'orderlistwithadd.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ORDERLISTWITHADD_H
#define UI_ORDERLISTWITHADD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_OrderListWithAdd
{
public:
    QPushButton *pushButton_addOrder;
    QTableView *tableView;

    void setupUi(QDialog *OrderListWithAdd)
    {
        if (OrderListWithAdd->objectName().isEmpty())
            OrderListWithAdd->setObjectName("OrderListWithAdd");
        OrderListWithAdd->resize(696, 430);
        pushButton_addOrder = new QPushButton(OrderListWithAdd);
        pushButton_addOrder->setObjectName("pushButton_addOrder");
        pushButton_addOrder->setGeometry(QRect(260, 380, 151, 29));
        tableView = new QTableView(OrderListWithAdd);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(20, 50, 661, 301));

        retranslateUi(OrderListWithAdd);

        QMetaObject::connectSlotsByName(OrderListWithAdd);
    } // setupUi

    void retranslateUi(QDialog *OrderListWithAdd)
    {
        OrderListWithAdd->setWindowTitle(QCoreApplication::translate("OrderListWithAdd", "Dialog", nullptr));
        pushButton_addOrder->setText(QCoreApplication::translate("OrderListWithAdd", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\267\320\260\320\272\320\260\320\267", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OrderListWithAdd: public Ui_OrderListWithAdd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ORDERLISTWITHADD_H
