/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_PriceList;
    QPushButton *pushButton_AddOrder;
    QPushButton *pushButton_Analytics;
    QPushButton *pushButton_Clients;
    QPushButton *pushButton_addPuzzle;
    QPushButton *pushButton_Production;
    QLabel *label_ConnectStatus;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(232, 308);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName("gridLayout_2");
        pushButton_PriceList = new QPushButton(centralwidget);
        pushButton_PriceList->setObjectName("pushButton_PriceList");

        gridLayout_2->addWidget(pushButton_PriceList, 5, 0, 1, 1);

        pushButton_AddOrder = new QPushButton(centralwidget);
        pushButton_AddOrder->setObjectName("pushButton_AddOrder");

        gridLayout_2->addWidget(pushButton_AddOrder, 0, 0, 1, 1);

        pushButton_Analytics = new QPushButton(centralwidget);
        pushButton_Analytics->setObjectName("pushButton_Analytics");

        gridLayout_2->addWidget(pushButton_Analytics, 4, 0, 1, 1);

        pushButton_Clients = new QPushButton(centralwidget);
        pushButton_Clients->setObjectName("pushButton_Clients");

        gridLayout_2->addWidget(pushButton_Clients, 6, 0, 1, 1);

        pushButton_addPuzzle = new QPushButton(centralwidget);
        pushButton_addPuzzle->setObjectName("pushButton_addPuzzle");

        gridLayout_2->addWidget(pushButton_addPuzzle, 1, 0, 1, 1);

        pushButton_Production = new QPushButton(centralwidget);
        pushButton_Production->setObjectName("pushButton_Production");

        gridLayout_2->addWidget(pushButton_Production, 3, 0, 1, 1);

        label_ConnectStatus = new QLabel(centralwidget);
        label_ConnectStatus->setObjectName("label_ConnectStatus");

        gridLayout_2->addWidget(label_ConnectStatus, 7, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 232, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton_PriceList->setText(QCoreApplication::translate("MainWindow", "\320\246\320\265\320\275\321\213", nullptr));
        pushButton_AddOrder->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\272\320\260\320\267\321\213", nullptr));
        pushButton_Analytics->setText(QCoreApplication::translate("MainWindow", "\320\220\320\275\320\260\320\273\320\270\321\202\320\270\320\272\320\260", nullptr));
        pushButton_Clients->setText(QCoreApplication::translate("MainWindow", "\320\232\320\273\320\270\320\265\320\275\321\202\321\213", nullptr));
        pushButton_addPuzzle->setText(QCoreApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\277\320\260\320\267\320\273", nullptr));
        pushButton_Production->setText(QCoreApplication::translate("MainWindow", "\320\237\321\200\320\276\320\270\320\267\320\262\320\276\320\264\321\201\321\202\320\262\320\276", nullptr));
        label_ConnectStatus->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
