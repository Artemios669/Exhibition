#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

class DatabaseManager {
public:
    // Метод для получения единственного экземпляра
    static DatabaseManager& instance() {
        static DatabaseManager instance; // Единственный экземпляр
        return instance;
    }

    QSqlDatabase getDatabase() {
        return db; // db — это ваш объект QSqlDatabase
    }
    // Устанавливает подключение к базе данных
    bool connect(const QString& host, const QString& dbName, const QString& user, const QString& password) {
        if (db.isOpen()) {
            qDebug() << "База данных уже подключена.";
            return true;
        }

        db = QSqlDatabase::addDatabase("QPSQL"); // Замените на ваш драйвер (например, QMYSQL, QSQLITE и т.д.)
        db.setHostName(host);
        db.setDatabaseName(dbName);
        db.setUserName(user);
        db.setPassword(password);

        if (!db.open()) {
            qDebug() << "Ошибка подключения к базе данных:" << db.lastError().text();
            return false;
        }

        qDebug() << "Успешное подключение к базе данных!";
        return true;
    }

    // Возвращает объект QSqlQuery
    QSqlQuery createQuery() {
        if (!db.isOpen()) {
            qDebug() << "База данных не подключена!";
        }
        return QSqlQuery(db);
    }

    // Закрыть подключение к базе данных
    void close() {
        if (db.isOpen()) {
            db.close();
            qDebug() << "Подключение к базе данных закрыто.";
        }
    }

private:
    QSqlDatabase db;

    // Приватный конструктор для Singleton
    DatabaseManager() {}

    // Удаляем конструкторы копирования и операторы присваивания
    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

    ~DatabaseManager() {
        close(); // Закрываем подключение при удалении объекта
    }
};

#endif // DATABASEMANAGER_H
