#include "mainwindow.h"
#include "DatabaseManager.h"
#include <QApplication>
#include <QDebug>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    if (DatabaseManager::instance().connect("localhost", "postgres", "postgres", "admin"))
    {
        QSqlQuery query = DatabaseManager::instance().createQuery();
    }
    return a.exec();
}
