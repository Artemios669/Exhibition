#pragma once
#ifndef ADDPUZZLES_H
#define ADDPUZZLES_H

#include <QDialog>
#include <QSqlQueryModel>
namespace Ui {
class AddPuzzles;
}

class AddPuzzles : public QDialog
{
    Q_OBJECT

public:
    void UpdateInfo();
    explicit AddPuzzles(QWidget *parent = nullptr);
    ~AddPuzzles();
public slots:
    void UpdateInformation();
private slots:
    void on_pushButton_AddSheet_clicked();

    void on_pushButton_AddPuzzle_clicked();

    void on_comboBox_Sheets_currentTextChanged(const QString &arg1);

private:
    Ui::AddPuzzles *ui;
    QSqlQueryModel *modal;
};

#endif // ADDPUZZLES_H
