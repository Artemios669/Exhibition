#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /*db = QSqlDatabase::addDatabase("QPSQL", "mydb");

    db.setHostName("localhost");

    db.setDatabaseName("postgres");

    db.setUserName("postgres");

    db.setPassword("admin");

    if (!db.open()) {
        ui->label_ConnectStatus->setText("Not connected");
    }
    else{
        ui->label_ConnectStatus->setText("Connected");
    }*/

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_addPuzzle_clicked()
{
    addPuzzles = new AddPuzzles(this);
    addPuzzles->show();
}


void MainWindow::on_pushButton_AddOrder_clicked()
{
    orderList = new OrderListWithAdd(this);
    orderList->show();
}


void MainWindow::on_pushButton_Production_clicked()
{
    production = new Production(this);
    production->show();
}

