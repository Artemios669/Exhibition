#ifndef ADDORDER_H
#define ADDORDER_H

#include <QDialog>
#include <QSqlTableModel>
namespace Ui {
class AddOrder;
}

class AddOrder : public QDialog
{
    Q_OBJECT

public:
    explicit AddOrder(QWidget *parent = nullptr);
    ~AddOrder();

private slots:
    void on_pushButton_AddOrder_clicked();
    void UpdateValue(const QString &arg1);
    void UpdateAmount(int i, int j);

private:
    Ui::AddOrder *ui;
    QSqlTableModel *table_model;
};

#endif // ADDORDER_H
