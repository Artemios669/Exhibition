#include "addproduction.h"
#include "ui_addproduction.h"
#include <QStandardItemModel>
#include <QSqlQueryModel>
AddProduction::AddProduction(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddProduction)
{
    ui->setupUi(this);

    QSqlQuery query = DatabaseManager::instance().createQuery();
    query.exec("SELECT * FROM order_list;");

    QStandardItemModel *model = new QStandardItemModel(ui->comboBox_OrderName);

    QStandardItem *empty_item = new QStandardItem("");
    model->appendRow(empty_item);

    while(query.next())
    {
        QStandardItem *item = new QStandardItem(query.value("order_name").toString());
        model->appendRow(item);
    }
    ui->comboBox_OrderName->setModel(model);
    ui->comboBox_OrderName->setCurrentIndex(0);
}

AddProduction::~AddProduction()
{
    delete ui;
}

void AddProduction::on_comboBox_StatusProduce_currentTextChanged(const QString &arg1)
{
    /*QSqlQuery query = DatabaseManager::instance().createQuery();

    query.prepare("UPDATE orders SET status = 'На производстве' WHERE id = 6");
    query.bindValue(":type_wood", wood);
    query.exec();
    query.next();
    int wood_price = query.value("wood_price").toInt();


    if (arg1 == "Принято в производство")*/
}


void AddProduction::on_comboBox_OrderName_currentTextChanged(const QString &arg1)
{
    QSqlQueryModel *model = new QSqlQueryModel();
    QSqlQuery query = DatabaseManager::instance().createQuery();
    query.prepare("SELECT puzzle_name_id, quantity FROM orders WHERE order_name_id = :arg1");
    query.bindValue(":arg1", arg1);
    query.exec();
    model->setQuery(query);
    ui->tableView->setModel(model);
}


void AddProduction::on_pushButton_addProduction_clicked()
{
    QSqlQuery query = DatabaseManager::instance().createQuery();

    QString order_name = ui->comboBox_OrderName->currentText();
    QString registration_date = ui->lineEdit_RegistrationDate->text();
    QString complete_date = ui->lineEdit_CompletedDate->text();
    QString status = ui->comboBox_StatusProduce->currentText();

    query.prepare("INSERT INTO production (order_name_id, registration_date, complete_date, status) VALUES (:order_name_id, :registration_date, :complete_date, :status);");
    query.bindValue(":order_name_id", order_name);
    query.bindValue(":registration_date",registration_date);
    query.bindValue(":complete_date", complete_date);
    query.bindValue(":status", status);
    query.exec();
    close();
}

