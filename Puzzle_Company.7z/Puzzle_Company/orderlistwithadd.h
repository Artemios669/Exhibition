#ifndef ORDERLISTWITHADD_H
#define ORDERLISTWITHADD_H

#include <QDialog>
#include "addorder.h"
#include "databasemanager.h"
namespace Ui {
class OrderListWithAdd;
}

class OrderListWithAdd : public QDialog
{
    Q_OBJECT

public:
    explicit OrderListWithAdd(QWidget *parent = nullptr);
    ~OrderListWithAdd();

private slots:
    void on_pushButton_addOrder_clicked();

private:
    Ui::OrderListWithAdd *ui;
    AddOrder *addOrder;
};

#endif // ORDERLISTWITHADD_H
