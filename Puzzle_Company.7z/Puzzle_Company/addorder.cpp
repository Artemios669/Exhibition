#include "addorder.h"
#include "ui_addorder.h"
#include <QSqlQueryModel>
#include <QComboBox>
#include "databasemanager.h"
#include <QDebug>
#include <QStandardItemModel>
AddOrder::AddOrder(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddOrder)
{
    ui->setupUi(this);
    QStringList name_col;
    name_col << "Товар" << "Цена" << "Количество" << "Сумма";
    ui->tableWidget->setHorizontalHeaderLabels(name_col);

    QSqlQuery query = DatabaseManager::instance().createQuery();
    query.exec("SELECT name FROM clients");

    QSqlQueryModel *modal = new QSqlQueryModel();
    modal->setQuery(query);
    ui->comboBox_Clients->setModel(modal);


    QSqlQuery query_price = DatabaseManager::instance().createQuery();
    query_price.exec("SELECT price FROM puzzles;");
    int row = 0;

    while (query_price.next())
    {
        QSqlQuery query_names = DatabaseManager::instance().createQuery();
        query_names.exec("SELECT name FROM puzzles;");

        QComboBox *comboBox = new QComboBox();

        QStandardItemModel *model = new QStandardItemModel(comboBox);

        QStandardItem *empty_item = new QStandardItem("");
        model->appendRow(empty_item);

        while(query_names.next())
        {
            QStandardItem *item = new QStandardItem(query_names.value("name").toString());
            model->appendRow(item);
        }
        comboBox->setModel(model);
        ui->tableWidget->setCellWidget(row, 0, comboBox);
        comboBox->setCurrentIndex(0);

        ++row;
        connect(comboBox, &QComboBox::currentTextChanged, this, &AddOrder::UpdateValue);
    }


    QSqlQuery query_statuses = DatabaseManager::instance().createQuery();
    query_statuses.exec("SELECT * FROM statuses;");

    QStandardItemModel *model = new QStandardItemModel(ui->comboBox_Status);

    QStandardItem *empty_item = new QStandardItem("");
    model->appendRow(empty_item);

    while(query_statuses.next())
    {
        QStandardItem *item = new QStandardItem(query_statuses.value("status").toString());
        model->appendRow(item);
    }
    ui->comboBox_Status->setModel(model);
    ui->comboBox_Status->setCurrentIndex(0);

    connect(ui->tableWidget, &QTableWidget::cellChanged, this, &AddOrder::UpdateAmount);
}

AddOrder::~AddOrder()
{
    delete ui;
}

void AddOrder::on_pushButton_AddOrder_clicked()
{
    QSqlQuery query = DatabaseManager::instance().createQuery();

    QString order_name = ui->lineEdit_name->text();
    QString registration_date = ui->lineEdit_RegistrationDate->text();
    QString client = ui->comboBox_Clients->currentText();
    QString complete_date = ui->lineEdit_CompleteDate->text();
    QString status = ui->comboBox_Status->currentText();

    int quantity = ui->tableWidget->item(0,2)->text().toInt();
    int amount = ui->tableWidget->item(0,3)->text().toInt();

    QWidget *widget = ui->tableWidget->cellWidget(0, 0);
    QComboBox *comboBox = qobject_cast<QComboBox *>(widget);
    QString puzzle_name = comboBox->currentText();

    query.prepare("INSERT INTO order_list (order_name, registration_date, client, complete_date, status) VALUES (:order_name_id, :registration_date, :client, :complete_date, :status);");
    query.bindValue(":order_name_id", order_name);
    query.bindValue(":registration_date",registration_date);
    query.bindValue(":client",client);
    query.bindValue(":complete_date", complete_date);
    query.bindValue(":status", status);
    query.exec();

    query.prepare("INSERT INTO orders (order_name_id, puzzle_name_id, quantity, amount) VALUES (:order_name_id, :puzzle_name_id, :quantity, :amount);");
    query.bindValue(":order_name_id", order_name);
    query.bindValue(":puzzle_name_id", puzzle_name);
    query.bindValue(":quantity", quantity);
    query.bindValue(":amount", amount);
    query.exec();
    qDebug() << registration_date << client << complete_date << status << quantity << amount << puzzle_name;
    close();
}

void AddOrder::UpdateValue(const QString &arg1)
{

    QSqlQuery query_price_upd = DatabaseManager::instance().createQuery();
    query_price_upd.prepare("SELECT price FROM puzzles WHERE name = :name");
    QString name = arg1;

    query_price_upd.bindValue(":name", name);
    query_price_upd.exec();
    while (query_price_upd.next())
    {
        int row = ui->tableWidget->currentRow();
        QTableWidgetItem *price_item = new QTableWidgetItem(query_price_upd.value("price").toString());
        ui->tableWidget->setItem(row, 1, price_item);
    }
}

void AddOrder::UpdateAmount(int i, int j)
{
    if (j == 2)
    {
        int amount_ = ui->tableWidget->item(i, 1)->text().toInt() * ui->tableWidget->item(i, 2)->text().toInt();
        //qDebug() << "измена" << ui->tableWidget->item(i, 1)->text().toInt() << ui->tableWidget->item(i, 2)->text().toInt() << amount_;
        QTableWidgetItem *amount_item = new QTableWidgetItem(QString::number(amount_));
        ui->tableWidget->setItem(i, 3, amount_item);
    }
}


