#include "addsheet.h"
#include "ui_addsheet.h"
#include "databasemanager.h"
#include "addpuzzles.h"
#include <qDebug>
#include <QSqlQueryModel>
AddSheet::AddSheet(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddSheet)
{
    ui->setupUi(this);

    QSqlQuery query = DatabaseManager::instance().createQuery();
    query.exec("SELECT name FROM wood");

    QSqlQueryModel *modal = new QSqlQueryModel();
    modal->setQuery(query);
    ui->comboBox_choiceWood->setModel(modal);

    addPuzzles = new AddPuzzles;
    connect(this, &AddSheet::requestUpdate, addPuzzles, &AddPuzzles::UpdateInformation);
}

AddSheet::~AddSheet()
{
    delete ui;
}

void AddSheet::on_pushButton_AddSheet_clicked()
{
    QSqlQuery query = DatabaseManager::instance().createQuery();

    QString name = ui->lineEdit_name->text();
    QString wood = ui->comboBox_choiceWood->currentText();
    int thickness = ui->comboBox_choiceThickness->currentText().toInt();

    query.prepare("SELECT * FROM price_list WHERE type_wood = :type_wood;");
    query.bindValue(":type_wood", wood);
    query.exec();
    query.next();
    int wood_price = query.value("wood_price").toInt();

    query.prepare("SELECT * FROM price_list WHERE type_wood = :type_wood;");
    query.bindValue(":type_wood", wood);
    query.exec();
    query.next();
    QString colPriceTKName = "mm" + ui->comboBox_choiceThickness->currentText() + "_price";
    float thickness_price = query.value(colPriceTKName).toFloat();

    query.prepare("INSERT INTO sheets (name, type_wood, thickness, price) VALUES (:name, :wood, :thickness, :price)");
    query.bindValue(":name", name);
    query.bindValue(":wood", wood);
    query.bindValue(":thickness", thickness);
    query.bindValue(":price", wood_price * thickness_price);
    query.exec();

    close();

    emit requestUpdate();
}


void AddSheet::on_comboBox_choiceWood_currentTextChanged(const QString &arg1)
{
    name = ui->comboBox_choiceWood->currentText() + ", " + ui->comboBox_choiceThickness->currentText() + " мм";
    ui->lineEdit_name->setText(name);
}

void AddSheet::on_comboBox_choiceThickness_currentTextChanged(const QString &arg1)
{
    name = ui->comboBox_choiceWood->currentText() + ", " + ui->comboBox_choiceThickness->currentText() + " мм";
    ui->lineEdit_name->setText(name);
}

