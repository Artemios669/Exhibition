#include "orderlistwithadd.h"
#include "ui_orderlistwithadd.h"
#include <QSqlQueryModel>
OrderListWithAdd::OrderListWithAdd(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::OrderListWithAdd)
{
    ui->setupUi(this);

    QSqlQueryModel *model = new QSqlQueryModel();
    QSqlQuery query = DatabaseManager::instance().createQuery();
    query.exec("SELECT * FROM order_list");
    model->setQuery(query);
    ui->tableView->setModel(model);
}

OrderListWithAdd::~OrderListWithAdd()
{
    delete ui;
}

void OrderListWithAdd::on_pushButton_addOrder_clicked()
{
    addOrder = new AddOrder(this);
    addOrder->show();
}

